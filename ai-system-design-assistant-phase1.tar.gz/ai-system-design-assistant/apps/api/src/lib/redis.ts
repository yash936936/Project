import Redis from 'ioredis';
const REDIS_URL = process.env.REDIS_URL ?? 'redis://localhost:6379';
export const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: null, enableReadyCheck: false, lazyConnect: true });
redis.on('error', (err) => console.error('[Redis] Error:', err.message));
redis.on('connect', () => console.info('[Redis] Connected'));
